
-- --------------------------------------------------------

--
-- Table structure for table `customerdetails`
--

CREATE TABLE `customerdetails` (
  `ResID` int(11) NOT NULL,
  `Fname` varchar(20) NOT NULL,
  `Lname` varchar(20) NOT NULL,
  `Phno` int(50) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Pwd` varchar(20) NOT NULL,
  `HsgLoc` varchar(80) NOT NULL,
  `StrtAdd` varchar(80) NOT NULL,
  `City` varchar(20) NOT NULL,
  `State` varchar(20) NOT NULL,
  `Zip` int(20) NOT NULL,
  `HsgLoc1` varchar(80) NOT NULL,
  `StrtAdd1` varchar(80) NOT NULL,
  `City1` varchar(20) NOT NULL,
  `State1` varchar(20) NOT NULL,
  `Zip1` int(20) NOT NULL,
  `isAdmin` int(2) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customerdetails`
--

INSERT INTO `customerdetails` (`ResID`, `Fname`, `Lname`, `Phno`, `Email`, `Pwd`, `HsgLoc`, `StrtAdd`, `City`, `State`, `Zip`, `HsgLoc1`, `StrtAdd1`, `City1`, `State1`, `Zip1`, `isAdmin`) VALUES
(1, 'Sarika', 'Pandey', 2147483647, 'sarika@something.com', '', 'C101,GOKUL VATIKA', 'KRISHNA TOWNSHIP, AMBADI ROAD', 'VASAI', 'Maharashtra', 401202, 'C101,GOKUL VATIKA', 'KRISHNA TOWNSHIP, AMBADI ROAD', 'VASAI', 'Maharashtra', 401202, 0),
(2, 'Rudy', 'Francisco', 775234, 'rudy@admin.com', 'admin@rudy', '239 Cemetery Road', 'Griffin GA', 'Bohemia', 'Walton', 235, '239 Cemetery Road', 'Griffin GA', 'Bohemia', 'Walton', 235, 1);
